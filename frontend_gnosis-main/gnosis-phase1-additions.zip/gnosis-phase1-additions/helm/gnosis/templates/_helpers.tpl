{{/*
Gnosis Helm Helpers
*/}}

{{/* Expand the name of the chart */}}
{{- define "gnosis.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Full image path: registry/image:tag */}}
{{- define "gnosis.image" -}}
{{- printf "%s/%s:%s" .registry .image .tag }}
{{- end }}

{{/* Common labels applied to every resource */}}
{{- define "gnosis.labels" -}}
app.kubernetes.io/managed-by: Helm
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end }}

{{/* Selector labels for a given service */}}
{{- define "gnosis.selectorLabels" -}}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/* Environment variables shared by ALL backend services */}}
{{- define "gnosis.commonEnv" -}}
- name: NODE_ENV
  value: "production"
- name: DB_HOST
  value: "postgres"
- name: DB_PORT
  value: "5432"
- name: DB_USER
  value: "postgres"
- name: DB_NAME
  value: "gnosis"
- name: DB_PASSWORD
  valueFrom:
    secretKeyRef:
      name: gnosis-secrets
      key: db-password
- name: JWT_SECRET
  valueFrom:
    secretKeyRef:
      name: gnosis-secrets
      key: jwt-secret
- name: REDIS_HOST
  value: "redis"
- name: REDIS_PORT
  value: "6379"
- name: REDIS_URL
  value: "redis://redis:6379"
{{- end }}

{{/* Standard liveness probe for Node.js services */}}
{{- define "gnosis.livenessProbe" -}}
livenessProbe:
  httpGet:
    path: /health
    port: http
  initialDelaySeconds: 30
  periodSeconds: 15
  failureThreshold: 3
  timeoutSeconds: 5
{{- end }}

{{/* Standard readiness probe for Node.js services */}}
{{- define "gnosis.readinessProbe" -}}
readinessProbe:
  httpGet:
    path: /health
    port: http
  initialDelaySeconds: 10
  periodSeconds: 10
  failureThreshold: 3
  timeoutSeconds: 3
{{- end }}
