# ─── GitHub Repository Secrets Required ─────────────────────────────
# Settings → Secrets and variables → Actions → New repository secret

## CI/CD Pipeline (ci-cd.yaml)

### OCIR — Oracle Cloud Container Registry
# OCI_TENANCY_NAMESPACE   → Oracle tenancy namespace (e.g. "ax3kl5fn...")
# OCI_USERNAME            → format: tenancy_namespace/user@email.com
# OCI_AUTH_TOKEN          → Generate at: OCI Console → User → Auth Tokens

### SonarQube (sonarcloud.io — free for public repos)
# SONAR_TOKEN             → Generate at: sonarcloud.io → My Account → Security
# SONAR_HOST_URL          → https://sonarcloud.io

### Slack notifications
# SLACK_WEBHOOK_URL       → Slack App → Incoming Webhooks → Add New Webhook

## Terraform (terraform.yaml)
# AWS_ACCESS_KEY_ID       → Until OCI account: AWS IAM access key
# AWS_SECRET_ACCESS_KEY   → AWS IAM secret key
#
# Phase 2 — OCI credentials:
# OCI_PRIVATE_KEY         → PEM private key content (entire file)
# OCI_CLI_USER            → User OCID
# OCI_CLI_TENANCY         → Tenancy OCID
# OCI_CLI_FINGERPRINT     → API key fingerprint
# OCI_CLI_REGION          → ap-mumbai-1

## GitHub Environment Protection (prod apply gate)
# Settings → Environments → prod → Required reviewers → add yourself
# This means: prod terraform apply only runs after manual approval

## Optional
# KIRA_GEMINI_API_KEY     → For KIRA AIOps (already in .env.example)
