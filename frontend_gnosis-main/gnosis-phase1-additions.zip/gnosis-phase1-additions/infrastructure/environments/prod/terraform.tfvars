# ─── Production Environment Variables ────────────────────────────────
# High availability — 3 nodes min, larger instances

project      = "gnosis"
cluster_name = "gnosis-prod-cluster"

# Phase 2 (OCI): VM.Standard.E4.Flex (2 OCPU, 16GB RAM)
node_instance_type = "t3.medium"
node_min           = 2
node_max           = 10
node_desired       = 3

vpc_cidr             = "10.0.0.0/16"
public_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24"]
private_subnet_cidrs = ["10.0.10.0/24", "10.0.11.0/24"]
availability_zones   = ["ap-south-1a", "ap-south-1b"]

gnosis_services = [
  "gnosis/api-gateway",
  "gnosis/auth-service",
  "gnosis/content-service",
  "gnosis/progress-service",
  "gnosis/xp-service",
  "gnosis/battle-service",
  "gnosis/notification-service",
  "gnosis/frontend"
]
