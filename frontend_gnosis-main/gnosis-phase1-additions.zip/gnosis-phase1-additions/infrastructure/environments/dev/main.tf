# ─── environments/dev/main.tf ────────────────────────────────────────
# Dev environment — uses OCI free tier resources
# Usage: cd infrastructure/environments/dev && terraform init && terraform apply

terraform {
  required_version = ">= 1.5"

  required_providers {
    # Phase 2: Switch to OCI provider
    # oci = {
    #   source  = "oracle/oci"
    #   version = "~> 6.0"
    # }
    # For now, using AWS structure — swap when OCI account is ready
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Phase 2: OCI Object Storage remote state
  # backend "s3" {
  #   bucket   = "gnosis-tfstate-dev"
  #   key      = "dev/terraform.tfstate"
  #   region   = "ap-mumbai-1"
  #   endpoint = "https://objectstorage.ap-mumbai-1.oraclecloud.com"
  #   skip_credentials_validation = true
  #   skip_region_validation      = true
  #   skip_metadata_api_check     = true
  # }

  # Until OCI account: use local state (already done in your existing code)
  backend "local" {
    path = "terraform.tfstate"
  }
}

# Call root modules with dev-specific variables
module "vpc" {
  source = "../../modules/vpc"

  project              = var.project
  vpc_cidr             = var.vpc_cidr
  public_subnet_cidrs  = var.public_subnet_cidrs
  private_subnet_cidrs = var.private_subnet_cidrs
  availability_zones   = var.availability_zones
}

module "eks" {
  source = "../../modules/eks"

  project            = var.project
  cluster_name       = var.cluster_name
  vpc_id             = module.vpc.vpc_id
  private_subnet_ids = module.vpc.private_subnet_ids
  public_subnet_ids  = module.vpc.public_subnet_ids
  node_instance_type = var.node_instance_type
  node_min           = var.node_min
  node_max           = var.node_max
  node_desired       = var.node_desired
}

module "ecr" {
  source = "../../modules/ecr"

  repositories = var.gnosis_services
}

module "argocd" {
  source = "../../modules/argocd"

  cluster_endpoint       = module.eks.cluster_endpoint
  cluster_ca_certificate = module.eks.cluster_ca_certificate
  cluster_name           = module.eks.cluster_name

  depends_on = [module.eks]
}
