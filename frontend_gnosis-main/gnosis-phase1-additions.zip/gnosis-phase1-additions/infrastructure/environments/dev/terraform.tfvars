# ─── Dev Environment Variables ───────────────────────────────────────
# These override the module defaults for dev (smaller, cheaper)

project      = "gnosis-dev"
cluster_name = "gnosis-dev-cluster"

# Smaller instances for dev — OCI free tier has VM.Standard.E2.1.Micro
node_instance_type = "t3.small"   # Phase 2: VM.Standard.E2.1 (OCI free)
node_min           = 1
node_max           = 2
node_desired       = 1

# Same VPC CIDR as prod but different AZ region prefix
vpc_cidr             = "10.1.0.0/16"
public_subnet_cidrs  = ["10.1.1.0/24", "10.1.2.0/24"]
private_subnet_cidrs = ["10.1.10.0/24", "10.1.11.0/24"]
availability_zones   = ["ap-south-1a", "ap-south-1b"]

gnosis_services = [
  "gnosis/api-gateway",
  "gnosis/auth-service",
  "gnosis/content-service",
  "gnosis/progress-service",
  "gnosis/xp-service",
  "gnosis/battle-service",
  "gnosis/notification-service",
  "gnosis/frontend"
]
